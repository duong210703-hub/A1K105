# STEMLab VN — Nền Tảng Thí Nghiệm Khoa Học Ảo (AAA Cartoon Storytelling Edition)

Nền tảng thí nghiệm khoa học ảo trực tuyến tương tác cao (lấy cảm hứng từ PhET Simulations), được tái thiết kế toàn diện theo phong cách **Full-screen Storytelling (Kể chuyện toàn màn hình)** kết hợp **Dải cuộn ngang (Horizontal Strips)** chuẩn các tựa game AAA.

---

## 🎨 Bảng Màu Chuẩn Từ Hình Ảnh Swatch
Nền tảng sử dụng bảng màu 5 sắc thái từ ảnh mẫu:
1. **Aqua Mint (#60EFDB)**: Điểm nhấn năng lượng, nút CTA, hạt electron.
2. **Pastel Mint (#BFF3E7)**: Thẻ thông tin, huy hiệu chương, điện trở gốm.
3. **Ice Powder Blue (#C6E6F1)**: Nền tranh minh họa, không gian phòng thí nghiệm.
4. **Vivid Sky Blue (#79CEED)**: Dây dẫn điện, bóng nước, liên kết ion.
5. **Muted Slate Denim (#6F89A4)**: Giá treo, xà cơ học, chi tiết phụ.
- **Màu Viền & Văn Bản (#1A2C3D)**: Đậm nét cartoon, độ tương phản cao, chống lóa mắt.

---

## 🚀 Các Tính Năng Đột Phá Mới Được Bổ Sung

### 1. Phông Chữ & Phong Cách Hoạt Họa Cartoon (Không Máy Móc)
- Toàn bộ giao diện sử dụng phông chữ **Trebuchet MS (Sans-Serif)** bo tròn, thân thiện với học sinh.
- **Hạn chế tối đa các icon máy móc**: Thay thế bằng nhãn chữ tiếng Việt sinh động, huy hiệu tròn, hộp thoại lời kể của "Giáo Sư Tí Nị", viền nét dày 2.5px - 3.5px và bóng đổ dạng khối hộp đặc trưng (`4px 4px 0px #1A2C3D`).

### 2. Bố Cục Full-screen Storytelling (Kể Chuyện Theo Hồi) & Dải Cuộn Ngang
- **Hồi I: Khởi Nguyên Thế Giới Lượng Tử**: Giới thiệu câu chuyện nhập vai thám hiểm khoa học, nhân vật dẫn truyện và bảng chỉ số thành tựu.
- **Hồi II: Dòng Chảy Năng Lượng & Thao Trường Ohm**: Phòng thí nghiệm PhET Định luật Ohm ($I = U/R$) với chữ cái co giãn theo giá trị, dòng electron chuyển động thực tế, bóng đèn tỏa sáng và công tắc đóng ngắt.
- **Hồi III: Biển Thí Nghiệm (Dải Cuộn Ngang)**: Bộ sưu tập mô phỏng dạng dải ngang (Horizontal Strips) giống các tựa game AAA, có nút lướt mượt mà.
- **Hồi IV: Vũ Điệu Con Lắc Không - Thời Gian**: Thí nghiệm con lắc đơn tương tác kéo thả chuột, chọn gia tốc trọng trường Trái Đất / Mặt Trăng / Sao Mộc và hai cột đo cơ năng $W_đ$ và $W_t$.
- **Hồi V: Đại Sảnh Liên Minh STEM**: Cổng tài nguyên giáo viên 5E, tải tài liệu và hướng dẫn tích hợp LMS.

### 3. Hoạt Ảnh Thị Sai Chuột (Mouse Parallax) & Motion Bồng Bềnh
- **Background Parallax**: Canvas chạy nền tự động tính toán tọa độ chuột và dịch chuyển các lớp bong bóng cartoon bồng bềnh theo các tầng độ sâu khác nhau (depth-lerp).
- Các khối UI sở hữu chuyển động nổi `gentleFloat` và hiệu ứng nhấn nút chân thực (`active: translate(3px, 3px)`).

### 4. Giao Diện Đăng Nhập Đa Nền Tảng (Google, Facebook, GitHub)
- Cửa sổ đăng nhập hoạt họa cartoon với đầy đủ 3 cổng: **Google**, **Facebook**, và **GitHub**.
- Giả lập phiên làm việc (Session), tự động cập nhật avatar và cấp bậc thám hiểm lên thanh công cụ.

### 5. Cơ Chế Bảo Mật Chống Tấn Công Chèn Mã Độc (XSS Defense)
- **Thẻ meta Content-Security-Policy (CSP)** ngăn chặn tải script trái phép.
- **Module XSSDefense**: Khử độc chuỗi văn bản (`escape`), lọc bỏ hoàn toàn các thẻ `<script>`, `<iframe>`, `on*` event handlers, và URL nguy hiểm `javascript:`.
- **Trạm Kiểm Thử XSS (XSS Inspector)** tích hợp sẵn trên giao diện cho phép nhập trực tiếp các mẫu mã độc và quan sát cơ chế phòng thủ thời gian thực.

### 6. Màn Hình Loading & Hoạt Ảnh 3 Chấm Nảy Khi Mạng Yếu
- Màn hình khởi động với bình hóa chất bồng bềnh và hoạt ảnh 3 chấm nảy (`dot-bounce`).
- Nút **"📶 Mạng Yếu"** trên thanh tiêu đề cho phép kích hoạt và trải nghiệm chế độ mô phỏng mạng yếu bất cứ lúc nào.

---

## 🖥️ Hướng Dẫn Mở & Trải Nghiệm

Nhấp đúp vào tệp:
`C:\Users\Dell\.gemini\antigravity\scratch\stem-lab-vn\index.html`

Hoặc chạy lệnh trên terminal để duyệt qua máy chủ cục bộ:
```bash
python -m http.server 3000
```
Sau đó truy cập: `http://localhost:3000`
